class testProduct
{
	constructor(){
		this.restrict='E';
		this.templateUrl='Scripts/Directives/testProduct/testProduct.html';
      this.scope={
        list:'='
      };
	}
 
	static builder()	{
		return new testProduct();
	}
}
export default testProduct;